package com.tco.misc;
import java.util.ArrayList;

public class Places extends ArrayList<Place> {
    
}
