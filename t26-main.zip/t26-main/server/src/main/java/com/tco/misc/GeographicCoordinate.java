package com.tco.misc;

public interface GeographicCoordinate {
    public Double latRadians();
    public Double lonRadians();
}
